<div class="footer">

	<ul>
		
	</ul>

</div>


<?php
wp_footer();
?>




</body>
</html>
