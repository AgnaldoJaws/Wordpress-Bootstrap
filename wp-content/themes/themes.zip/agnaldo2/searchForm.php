
<form action="" method="get"
 accept-charset="utf-u" id="searchForm" role="search">
 <di>
 	<input type="text" name="s" id="s" value="Pesquisar no site"
onblur="if(this.value=='') this.value='Pesquisar no site';"
onfocus="if(this.value =='Pesquisar no site') this.value='';"/>"
 <input type="submit" id="searchsubmit" value="Buscar" />
 
 
 </di>
 
 
 </form>